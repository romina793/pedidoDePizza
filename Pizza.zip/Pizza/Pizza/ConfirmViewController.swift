//
//  ConfirmViewController.swift
//  Pizza
//
//  Created by Romina Pozzuto on 23/12/2019.
//  Copyright © 2019 Romina Pozzuto. All rights reserved.
//

import UIKit

class ConfirmViewController: ViewController {
    
    @IBOutlet weak var tableViewConfirm: UITableView!
    
    var SwitchStateIngredientes: [String] = []
    var switchStateIngredientes: String?
    var switchStateQueso: String?
    var switchStateMasa: String?
    var switchStateTamaño: String?
    
    override func viewDidLoad() {
        self.configureTableView()
        self.tableViewConfirm.dataSource = self
        self.tableViewConfirm.delegate = self
        self.loadDataCellValues()
        self.navigationItem.setHidesBackButton(true, animated:true);
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setConfigurationNavigationItem()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationItem.title = ""
    }
    
    // Set configuration Navigation Item
    override func setConfigurationNavigationItem() {
        self.navigationItem.title = "¡Confirma tu pedido!"
    }
    
    //configure tableView
    func configureTableView() {
        //Detail cells
        self.tableViewConfirm.register(ConfirmationCell.nib, forCellReuseIdentifier: ConfirmationCell.identifier)
    }
    
    @IBAction func buttonEdit(_ sender: Any) {
        self.backToInit()
    }
    
    func backToInit() {
      if let navigationController = self.navigationController {
        for item in navigationController.viewControllers{
          if let viewController = item as? SelectedSizeViewController {
            navigationController.popToViewController(viewController, animated: true)
          }
        }
      }
    }
    
    
    @IBAction func buttonConfirm(_ sender: Any) {
        performSegue(withIdentifier: "okSegue", sender: nil)
    }
    
    //propieties detal cells
       private var sectionsTitles :[String] = ["Tamaño", "Tipo de masa", "Tipo de queso", "Ingredientes"]
       
       private var confirmationTitles :[String] = ["Seleccionado"]
       
       private var confirmationValuesTamaño = [String]()
       private var confirmationValuesMasa = [String]()
       private var confirmationValuesQueso = [String]()
       private var confirmationValuesIngredients = [String]()


    

    func loadDataCellValues(){
        confirmationValuesTamaño.append(switchStateTamaño ?? "-")
        confirmationValuesMasa.append(switchStateMasa ?? "-")
        confirmationValuesQueso.append(switchStateQueso ?? "-")
        confirmationValuesIngredients.append(switchStateIngredientes ?? "-")
        
    }
    
    func setSwitchValueIngredientes(switchState: String) {
          self.switchStateIngredientes = switchState
         }


   func setSwitchValueQueso(switchState: String) {
        self.switchStateQueso = switchState
         }

   func setSwitchValueMasa(switchState: String) {
        self.switchStateMasa = switchState
         }

   func setSwitchValue(switchState: String) {
        self.switchStateTamaño = switchState
        }
    
}

extension ConfirmViewController: UITableViewDataSource, UITableViewDelegate {

    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
     }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: ConfirmationCell.identifier) as? ConfirmationCell

        if (indexPath.section == 0) {
            cell?.labelIzquierda.text = confirmationTitles[indexPath.row]
            cell?.labelDerecha.text = confirmationValuesTamaño[indexPath.row]
        } else if (indexPath.section == 1) {
            cell?.labelIzquierda.text = confirmationTitles[indexPath.row]
            cell?.labelDerecha.text = confirmationValuesMasa[indexPath.row]
        } else if (indexPath.section == 2) {
            cell?.labelIzquierda.text = confirmationTitles[indexPath.row]
            cell?.labelDerecha.text = confirmationValuesQueso[indexPath.row]
        }  else if (indexPath.section == 3) {
            cell?.labelIzquierda.text = confirmationTitles[indexPath.row]
            cell?.labelDerecha.text = confirmationValuesIngredients[indexPath.row]
        }

        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
         return 30.0
     }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView: UIView = UIView(frame: CGRect(x: 20, y: 0, width: 100, height: 60))

        let label : UILabel = UILabel()
        label.text = sectionsTitles[section]
        label.textColor = UIColor.white
        headerView.backgroundColor = UIColor.orange
        headerView.addSubview(label)
        
        let leadingConstraint = NSLayoutConstraint(item: label, attribute: .leading, relatedBy: .equal, toItem: headerView, attribute: .leading, multiplier: 1, constant: 8)
        let topConstraint = NSLayoutConstraint(item: label, attribute: .top, relatedBy: .equal, toItem: headerView, attribute: .top, multiplier: 1, constant: 8)
        label.translatesAutoresizingMaskIntoConstraints = false

        headerView.addConstraints([leadingConstraint, topConstraint])
        
        return headerView
        
        
    }

}
