//
//  SelectedCheeseViewController.swift
//  Pizza
//
//  Created by Romina Pozzuto on 23/12/2019.
//  Copyright © 2019 Romina Pozzuto. All rights reserved.
//

import UIKit

class SelectedCheeseViewController: ViewController {
    
    var switchStateTamaño: String?
    var switchStateMasa: String?

    
    @IBOutlet weak var switchMouzzarella: UISwitch!
    
    @IBOutlet weak var switchCheddar: UISwitch!
    
    @IBOutlet weak var switchParmessano: UISwitch!
    
    @IBOutlet weak var switchSInQueso: UISwitch!
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setConfigurationNavigationItem()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationItem.title = ""
    }
    
    // Set configuration Navigation Item
    override func setConfigurationNavigationItem() {
        self.navigationItem.title = "Pedí tu pizza"
    }
    
    func showSimpleAlert() {
        let alert = UIAlertController(title: "Selecciona", message: "Debes seleccionar una opción",         preferredStyle: .alert)

        alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: { _ in
            //Cancel Action
        }))

        self.present(alert, animated: true, completion: nil)
    }
        
    
    func validationForView() {
        if self.switchMouzzarella.isOn == false &&  self.switchCheddar.isOn == false && self.switchParmessano.isOn == false && self.switchSInQueso.isOn == false {
            self.showSimpleAlert()
        } else if self.switchMouzzarella.isOn &&  self.switchCheddar.isOn && self.switchParmessano.isOn  && self.switchSInQueso.isOn  {
            self.showSimpleAlert()
        }
        
    }
    
    @IBAction func buttonNext(_ sender: Any) {
        self.validationForView()
        performSegue(withIdentifier: "selectedIngredientsSegue", sender: nil)
    }
    
    func setSwitchValueMasa(switchState: String) {
        self.switchStateMasa = switchState
       }
    
    func getSwitchValueMasa() -> String {
           return self.switchStateMasa ?? ""
       }
    
    func setSwitchValue(switchStateTamaño: String) {
        self.switchStateTamaño = switchStateTamaño
         }
    
    func getSwitchValueTamaño() -> String {
        return self.switchStateTamaño ?? ""
    }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.setSwitchValue(switchStateTamaño: self.getSwitchValueTamaño())
        self.setSwitchValueMasa(switchState: self.getSwitchValueMasa())
        let switchStateQueso = self.optionSelectedPizza()
        if let controllerDestino = segue.destination as? SelectedIngredientsViewController {
            controllerDestino.setSwitchValue(switchStateTamaño: self.getSwitchValueTamaño())
            controllerDestino.setSwitchValueMasa(switchState: self.getSwitchValueMasa())
            controllerDestino.setSwitchValueQueso(switchState: switchStateQueso)
        }
    }
    
    func optionSelectedPizza() -> String {
        if self.switchMouzzarella.isOn {
            return "Mouzzarella"
        }  else if self.switchCheddar.isOn {
            return "Cheddar"
        } else if self.switchParmessano.isOn {
            return "Parmessano"
        }else if self.switchSInQueso.isOn {
            return "Sin Queso"
        }
        return ""
    }
}
