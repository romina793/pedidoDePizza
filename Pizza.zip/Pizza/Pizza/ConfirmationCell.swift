//
//  ConfirmationCell.swift
//  Pizza
//
//  Created by Romina Pozzuto on 27/12/2019.
//  Copyright © 2019 Romina Pozzuto. All rights reserved.
//

import UIKit

class ConfirmationCell: UITableViewCell {
    
    @IBOutlet weak var labelIzquierda: UILabel!
    
    @IBOutlet weak var labelDerecha: UILabel!
    
    static var identifier : String {
        return String(describing: self)
    }

    static var nib : UINib {
        return UINib(nibName: identifier, bundle: nil)
    }
}

