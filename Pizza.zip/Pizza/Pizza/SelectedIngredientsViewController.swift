//
//  SelectedIngredientsViewController.swift
//  Pizza
//
//  Created by Romina Pozzuto on 23/12/2019.
//  Copyright © 2019 Romina Pozzuto. All rights reserved.
//

import UIKit

class SelectedIngredientsViewController: ViewController {
    
    @IBOutlet weak var switchJamon: UISwitch!
    
    @IBOutlet weak var switchPepperoni: UISwitch!
    
    @IBOutlet weak var switchPavo: UISwitch!
    
    @IBOutlet weak var switchSalchica: UISwitch!
    
    @IBOutlet weak var switchAceituna: UISwitch!
    
    @IBOutlet weak var switchCebollla: UISwitch!
    
    @IBOutlet weak var switchPimienta: UISwitch!
    
    @IBOutlet weak var switchPiña: UISwitch!
    
    @IBOutlet weak var switchAnchoa: UISwitch!
    
    var switchStateQueso: String?
    var switchStateMasa: String?
    var switchStateTamaño: String?

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setConfigurationNavigationItem()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationItem.title = ""
    }
    
    // Set configuration Navigation Item
    override func setConfigurationNavigationItem() {
        self.navigationItem.title = "Pedí tu pizza"
    }
    
    func showSimpleAlert() {
           let alert = UIAlertController(title: "Selecciona", message: "Debes seleccionar una opción",         preferredStyle: .alert)

           alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: { _ in
               //Cancel Action
           }))

           self.present(alert, animated: true, completion: nil)
       }
           
       
       func validationForView() {
        if self.switchJamon.isOn == false &&  self.switchPepperoni.isOn == false && self.switchPavo.isOn == false && self.switchSalchica.isOn == false && self.switchAceituna.isOn == false && self.switchCebollla.isOn == false && self.switchPimienta.isOn == false && self.switchPiña.isOn  == false && self.switchAnchoa.isOn  == false {
               self.showSimpleAlert()
           } else if self.switchJamon.isOn &&  self.switchPepperoni.isOn && self.switchPavo.isOn && self.switchSalchica.isOn && self.switchAceituna.isOn && self.switchCebollla.isOn  && self.switchPimienta.isOn && self.switchPiña.isOn && self.switchAnchoa.isOn {
               self.showSimpleAlert()
           }
           
       }
    
    @IBAction func buttonFinish(_ sender: Any) {
        self.validationForView()
        performSegue(withIdentifier: "confirmSegue", sender: nil)
    }
    
    func setSwitchValueQueso(switchState: String) {
        self.switchStateQueso = switchState
       }
    
    func getSwitchValueQueso() -> String {
           return self.switchStateQueso ?? ""
       }
    
    func setSwitchValueMasa(switchState: String) {
        self.switchStateMasa = switchState
       }
    
    func getSwitchValueMasa() -> String {
        return self.switchStateMasa ?? ""
    }
    
    func setSwitchValue(switchStateTamaño: String) {
          self.switchStateTamaño = switchStateTamaño
         }
    
    func getSwitchValueTamaño() -> String {
        return self.switchStateTamaño ?? ""
    }
    
  

    func optionSelectedPizza() -> String{
    
          if self.switchJamon.isOn {
              return "Jamón"
          }  else if self.switchPepperoni.isOn {
              return "Peppenoni"
          } else if self.switchPavo.isOn {
              return "Pavo"
          } else if self.switchSalchica.isOn {
              return "Salchicha"
          } else if self.switchAceituna.isOn {
              return "Aceituna"
          } else if self.switchCebollla.isOn {
              return "Cebolla"
          } else if self.switchPimienta.isOn {
              return "Pimienta"
          } else if self.switchPiña.isOn {
              return "Piña"
          } else if self.switchAnchoa.isOn {
              return "Anchoa"
          }
          return ""
      }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.setSwitchValue(switchStateTamaño: self.getSwitchValueTamaño())
        self.setSwitchValueMasa(switchState: self.getSwitchValueMasa())
        self.setSwitchValueQueso(switchState: self.getSwitchValueQueso())
        let switchStateIngrediente = self.optionSelectedPizza()
        if let controllerDestino = segue.destination as? ConfirmViewController {
            controllerDestino.setSwitchValue(switchState: self.getSwitchValueTamaño())
            controllerDestino.setSwitchValueMasa(switchState: self.getSwitchValueMasa())
            controllerDestino.setSwitchValueQueso(switchState: self.getSwitchValueQueso())
            controllerDestino.setSwitchValueIngredientes(switchState: switchStateIngrediente)

          

        }
    }
}
