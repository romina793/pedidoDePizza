//
//  SelectedMassViewController.swift
//  Pizza
//
//  Created by Romina Pozzuto on 23/12/2019.
//  Copyright © 2019 Romina Pozzuto. All rights reserved.
//

import UIKit

class SelectedMassViewController: ViewController {
    
    var switchStateTamaño: String?
    var optionSelected : String?
    
    @IBOutlet weak var switchDelgada: UISwitch!
    
    @IBOutlet weak var switchCrujiente: UISwitch!
    
    @IBOutlet weak var switchGruesa: UISwitch!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setConfigurationNavigationItem()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationItem.title = ""
    }
    
    // Set configuration Navigation Item
    override func setConfigurationNavigationItem() {
        self.navigationItem.title = "Pedí tu pizza"
    }
    
    @IBAction func buttonNext(_ sender: Any) {
        self.validationForView()
        performSegue(withIdentifier: "selectedCheeseSegue", sender: nil)
        
    }
    func showSimpleAlert() {
          let alert = UIAlertController(title: "Selecciona", message: "Debes seleccionar una opción",         preferredStyle: .alert)

          alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: { _ in
              //Cancel Action
          }))

          self.present(alert, animated: true, completion: nil)
      }
          
      
      func validationForView() {
          if self.switchDelgada.isOn == false &&  self.switchCrujiente.isOn == false && self.switchGruesa.isOn == false {
              self.showSimpleAlert()
          } else if self.switchDelgada.isOn &&  self.switchGruesa.isOn && self.switchGruesa.isOn {
              self.showSimpleAlert()
          }
          
      }
    
    func optionSelectedPizza() -> String {
        if self.switchDelgada.isOn {
            return "Delgada"
        }  else if self.switchCrujiente.isOn {
            return "Crujiente"
        } else if self.switchGruesa.isOn {
            return "Gruesa"
        }
        return ""
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        self.setSwitchValue(switchStateTamaño: self.getSwitchValueTamaño())
        let switchStateMasa = self.optionSelectedPizza()
        if let controllerDestino = segue.destination as? SelectedCheeseViewController {
           controllerDestino.setSwitchValueMasa(switchState: switchStateMasa)
         controllerDestino.setSwitchValue(switchStateTamaño: self.getSwitchValueTamaño())

           }
    }
    
    func setSwitchValue(switchStateTamaño: String) {
        self.switchStateTamaño = switchStateTamaño
       }
    
    func getSwitchValueTamaño() -> String {
           return self.switchStateTamaño ?? ""
       }
    
}
