//
//  ViewController.swift
//  Pizza
//
//  Created by Romina Pozzuto on 19/12/2019.
//  Copyright © 2019 Romina Pozzuto. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setConfigurationNavigationItem()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationItem.title = ""
    }
    
    // Set configuration Navigation Item
    func setConfigurationNavigationItem() {
        self.navigationItem.title = "Pedí tu pizza"
    }
    
    @IBAction func buttonStart(_ sender: Any) {
        performSegue(withIdentifier: "selectedSizeSegue", sender: nil)
    }
    
    
    

}

