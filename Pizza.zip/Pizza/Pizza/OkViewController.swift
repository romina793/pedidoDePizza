//
//  OkViewController.swift
//  Pizza
//
//  Created by Romina Pozzuto on 23/12/2019.
//  Copyright © 2019 Romina Pozzuto. All rights reserved.
//

import UIKit

class OkViewController: ViewController {
    
    override func viewDidLoad() {
    self.navigationItem.setHidesBackButton(true, animated:true);
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setConfigurationNavigationItem()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationItem.title = ""
    }
    
    // Set configuration Navigation Item
    override func setConfigurationNavigationItem() {
        self.navigationItem.title = "¡Gracias por elegirnos!"
    }
    
    @IBAction func buttonBackStart(_ sender: Any) {
        self.backStart()
    }
    
    
    func backStart() {
        if let navigationController = self.navigationController {
          for item in navigationController.viewControllers{
            if let viewController = item as? ViewController {
              navigationController.popToViewController(viewController, animated: true)
            }
          }
        }
      }
    
}
