//
//  SelectedSizeViewController.swift
//  Pizza
//
//  Created by Romina Pozzuto on 23/12/2019.
//  Copyright © 2019 Romina Pozzuto. All rights reserved.
//

import UIKit

class SelectedSizeViewController: ViewController, UIAlertViewDelegate {
    
    
    @IBOutlet var switchChica: UISwitch!
    
    @IBOutlet var switchMediana: UISwitch!
    
    @IBOutlet var switchGrande: UISwitch!
    
    
    var switchState: Bool?
    var optionSelected : String?
    
    
    override func viewDidLoad() {
        
        
    }
    
    func showSimpleAlert() {
        let alert = UIAlertController(title: "Selecciona", message: "Debes seleccionar una opción",         preferredStyle: .alert)

        alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: { _ in
            //Cancel Action
        }))

        self.present(alert, animated: true, completion: nil)
    }
        
    
    func validationForView() {
        if self.switchChica.isOn == false &&  self.switchMediana.isOn == false && self.switchGrande.isOn == false {
            self.showSimpleAlert()
        } else if self.switchChica.isOn &&  self.switchMediana.isOn && self.switchGrande.isOn {
            self.showSimpleAlert()
        }
        
    }

    
    func optionSelectedPizza() -> String {
        if self.switchChica.isOn {
            return "Chica"
        }  else if self.switchMediana.isOn {
            return "Mediana"
        } else if self.switchGrande.isOn {
            return "Grande"
        }
        return ""
    }
    
    
    func setSwitchValue(switchState: Bool) {
        if switchState != false  {
            self.optionSelected = "Requerido"
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setConfigurationNavigationItem()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationItem.title = ""
    }
    
    // Set configuration Navigation Item
    override func setConfigurationNavigationItem() {
        self.navigationItem.title = "Pedí tu pizza"
    }
    
    @IBAction func buttonNext(_ sender: Any) {
        self.validationForView()
        performSegue(withIdentifier: "selectedMassSegue", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
         let switchStateTamaño = self.optionSelectedPizza()
         if let controllerDestino = segue.destination as? SelectedMassViewController {
            controllerDestino.setSwitchValue(switchStateTamaño: switchStateTamaño)
            }
        }
    
   

}
